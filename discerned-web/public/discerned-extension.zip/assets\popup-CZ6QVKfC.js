import"./modulepreload-polyfill-YP0FEG5d.js";import{i as o}from"./theme-D4slifHB.js";import"./types-DRWnlWVG.js";o();
